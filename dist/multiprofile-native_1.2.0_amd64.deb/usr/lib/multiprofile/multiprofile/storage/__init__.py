"""XDG storage helpers."""
