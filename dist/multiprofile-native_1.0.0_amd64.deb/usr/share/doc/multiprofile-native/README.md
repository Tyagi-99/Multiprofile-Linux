# Multiprofile Native (Linux)

Native Ubuntu/Linux rebuild of the Multiprofile manager (SOURCE -> BUILD -> TEST -> DEB).

This is a clean-room Linux host for UI/extension assets you are authorized to use.
It does not require Wine or the original Windows .exe.

## Stack
- Python 3.11+
- Flask local API
- Optional pywebview (GTK/WebKit) desktop window
- System Chromium/Chrome for profile launch

## Dev quick start
```bash
cd multiprofile-native
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[ui]"
python -m multiprofile --server-only
# open http://127.0.0.1:8765/
```

## Build .deb
```bash
./build-deb.sh
# => dist/multiprofile-native_1.0.0_amd64.deb
```

## XDG paths
- ~/.config/multiprofile/
- ~/.local/share/multiprofile/
- ~/.cache/multiprofile/
